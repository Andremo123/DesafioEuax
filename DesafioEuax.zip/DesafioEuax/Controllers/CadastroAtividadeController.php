<?php
include("../Class/ClassCRUD.php");

$nome_projeto=filter_input(INPUT_POST,'nome_atividade',FILTER_SANITIZE_SPECIAL_CHARS);
$data_inicio=filter_input(INPUT_POST,'data_inicio',FILTER_SANITIZE_SPECIAL_CHARS);
$data_fim=filter_input(INPUT_POST,'data_fim',FILTER_SANITIZE_SPECIAL_CHARS);
$finalizada=filter_input(INPUT_POST,'data_fim',FILTER_DEFAULT);
$crud=new ClassCRUD();
$crud->insertDB(
    "atividade",
    "?,?,?,?",
    "sssb",
    array(
    $nome_projeto,
    $data_inicio,
    $data_fim,
    $finalizada
    )
)
 ?>