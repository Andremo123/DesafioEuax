<?php include("Includes/Header.php"); ?>

<div class="Content">
    <?php
    include("Class/ClassCRUD.php");
    ?>

    <div class="container">
        <form method="post" action="Controllers/CadastroProjetoController.php">
            <h2>Cadastro de Projeto</h2>
            <label>
                Nome do Projeto
            </label>
            <input type="text" id="nome_projeto" name="nome_projeto" />
            <label>
                Data de Inicio
            </label>
            <input type="date" id="data_inicio" name="data_inicio" />
            <label>
                Data de Fim
            </label>
            <input type="date" id="data_fim" name="data_fim" />
            <input type="submit"  class="waves-effect waves-light btn-small" value="cadastrar"/>
        </form>
    </div>
</div>

<?php include("Includes/Footer.php"); ?>