<?php

include("ClassConexao.php");

class ClassCRUD extends ClassConexao
{
    private $crud;
    private $contador;

    private function preparedStatements($query, $tipos,$parametros)
    {
        $this->countParametros($parametros);
        $this->crud = $this->conectaDB()->prepare($query);

        if ($this->contador > 0) 
        {
            $callParametros = array();
            foreach($parametros as $key => $parametro)
            {
                $callParametros[$key] = $parametros[$key];
            }
            array_unshift($callParametros, $tipos);
            call_user_func_array(array($this->crud,'bind_param'),$callParametros);
        }
    
    $this->crud->execute();
    $this->resultado=$this->crud->get_result();
    }


    public function countParametros($parametros)
    {
        $this->contador = count($parametros);
    }

    public function insertDB($tabela, $condicao, $tipos,$parametros)
    {
        $this->preparedStatements("insert into {$tabela} values ({$condicao})" , $tipos, $parametros);
        return $this->crud;
    }
    public function selectDB($campos, $tabela, $condicao, $parametros)
    {
        $this->preparedStatements("select {$campos} from {$tabela}", $condicao, $parametros);
        return $this->crud;
    }
}
