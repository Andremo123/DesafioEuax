<?php

abstract class ClassConexao
{
    public function conectaDB()
    {
        try {
            $con = new mysqli("localhost", "root", "password", "desafio_euax");
            return $con;
        }
            catch (Exception $erro) 
            {
                return $erro->getMessage();
            }
        
    }
}