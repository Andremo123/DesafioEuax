<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Desafio Euax - Gestão de Projetos</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
    <nav class="light-green lighten-1" role="navigation">
        <div class="nav-wrapper container"><a id="logo-container" href="index.php" class="brand-logo">Project Manager</a>
            <ul class="right hide-on-med-and-down">
                <li><a href="cadastro_projeto.php">Cadastrar Projeto</a></li>
            </ul>
            <ul class="right hide-on-med-and-down">
                <li><a href="cadastro_atividade.php">Cadastrar Atividade</a></li>
            </ul>
        </div>
    </nav>