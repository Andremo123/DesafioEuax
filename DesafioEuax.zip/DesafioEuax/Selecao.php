<?php
include("Class/ClassCRUD.php");
?>

<div class="Content">
<table class="TabelaCrud">
    <tr>
        <td>Nome do projeto</td>
        <td>Data de Inicio</td>
        <td>Data de fim</td>
    </tr>

    <!-- <?php
        $crud=new ClassCrud();
        $bfetch=$crud->selectDB(
            "*",
            "projeto",
            "",
            array()
        );

        //while ($fetch = $bFetch->fetchAll()){
        // while ($fetch = $bFetch->fetch(PDO::FETCH_ASSOC)){
            ?>
            <tr>
                <td><?php echo $Fetch[1]; ?></td>
                <td><?php echo $Fetch[2]; ?></td>
                <td><?php echo $Fetch[3]; ?></td>
            </tr> 
        }


    ?>         -->
        
</table>
</div>
<?php include("Includes/Footer.php");?>